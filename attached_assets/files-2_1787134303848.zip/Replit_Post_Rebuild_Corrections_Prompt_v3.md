# Replit Prompt — Post-Rebuild Corrections (v3)

Supersedes v2. Five items following the MRP history rebuild (`99090b4`). The rebuild itself was sound — 6,303 codes, the four unsourced periods gone, all 150 Sparsh mappings intact. These are the corrections.

Input file: `Prayag_Discontinued_Correction.xlsx`

**What changed since v2:** section 3 is new. Eighteen price rows currently in the database do not exist in the live source sheet and must be deleted. Everything else is carried over unchanged.

---

## 1. The withdrawal-marker rule

Two separate defects have come from misreading `REMOVED` in the source workbooks. Fix the rule once, in the loader, and both go away. Sections 2 and 3 are consequences of getting this right.

### Part one — a price and a withdrawal marker are not in conflict

They answer different questions and must both be read:

- The **price column** answers *what does it cost*.
- The **status column** answers *is it still on the list*.

A price says nothing about whether a product survives into that period, so it cannot contradict a withdrawal marker. When a code carries both for the same period, **the marker governs whether the product exists; the price governs what it would cost if it did.** Record both. Do not treat the presence of a price as evidence the product is live.

### Part two — every row must agree before a code is withdrawn

A code is withdrawn in a period **only if every row carrying it in that period is marked withdrawn.** One marked row is not enough.

The CP `MASTER` sheet holds **one row per (range, code) pair**. A shared component appears once for every range that uses it. `BD-40` — Single Lever Basin Mixer body — sits in about 89 rows across ASPIRE 52, ORBIT 53, AQUA 54, OCEAN 55, POLO 60, BLAZE 62, VIRGO P66, VINCENT 66, MARCUS 68, MACASA 76, URBONA 78, SAGA 79F, CYGNUS 71, EVIAN 87, NIAGARA 81, EUROPA 90 and LAGUNA 93. When a **range** is withdrawn — EMERALD 61, OPUS 89 — the rows for that range read `REMOVED`, but the component continues everywhere else. `BD-40` has **12 removed rows against 77 clean ones**.

Group by code first, then require unanimity within the period.

---

## 2. Apply the rule: 61 codes are wrongly discontinued

You cleared `BD-40` because an acceptance test caught it. It was not a special case — **sixty more codes carry the same defect**, and nothing will catch them. They will disappear from the catalogue on their division's revision date, silently.

Under part two, 98 of the 159 are genuinely withdrawn and 61 are not.

- **Sheet `1_UNMARK_not_discontinued`** — 61 codes. Set `discontinued_from = NULL` on each. `BD-40` is in this list; clearing it again is a no-op.
- **Sheet `2_Confirmed_discontinued`** — 98 codes. These keep their `discontinued_from`. Verify no code outside this list carries a withdrawal date.
- **Fix the loader**, not just the rows. If the rule stays as it is, the next load reintroduces all 61.

---

## 3. Delete 18 price rows that do not exist in the source

**This item is new.** The database currently holds 12,768 price rows. Eighteen of them are not in the live price list.

The nine 600-series sinks and their nine Matt twins each have a `2026-09-01` row carrying a price:

```
616-D  618-D  620-D  622-D  623-D  624-D  624-XD  624-SD  625-D
616-DM 618-DM 620-DM 622-DM 623-DM 624-DM 624-XDM 624-SDM 625-DM
```

In the workbook downloaded on 19 August, those September MRP cells held computed values — 2,690 / 2,860 / 3,040 and so on. In the **live Google Sheet, viewed on 19 August**, the same cells are **empty**; only the `Removed` marker is present. The values were cleared at source.

**Delete those 18 rows.** Keep every `2026-03-05` row for the same codes — `616-D` must still resolve to 2,490 on 31 August 2026. Row count goes from **12,768 to 12,750**. Distinct item codes stay at **6,303**, because all 18 codes retain their March price.

These rows are unreachable today, since a withdrawn product never resolves on or after its withdrawal date. Delete them anyway. They are figures Prayag never published, and if the 600-series withdrawal were ever reversed they would quietly become live prices.

The corrected file is `Prayag_MRP_AllPeriods_Rebuild_v3.xlsx` if you want to reload rather than delete in place. Either is acceptable; deleting the 18 is less disruptive.

---

## 4. The competitor gap formula needs a single-row trace

You reported the median Sparsh gap moving from **−8.48% to −0.99%** where the brief predicted **+3% → +10.8%**. Do not chase this with dataset-wide medians. Two facts narrow it:

- The **shift** is +7.49 points against a predicted +7.8. Near-identical — the rebuild moved the data correctly.
- The **baseline** differs by a consistent ~11.6 points, and the sign is inverted.

Right magnitude, wrong sign and offset, is the signature of a formula problem rather than a data problem.

### Trace this one row

Prayag `134-V` (Sink Mixer Foam Flow with Flange) ↔ Sparsh Pearl `RPS-2285`:

| Value | Amount |
|---|---:|
| Prayag MRP w.e.f. 05 Mar 2026 | 1,262.35 |
| Prayag MRP w.e.f. 01 Sep 2026 | 1,364.00 |
| Sparsh Pearl Vol 6.2 MRP | 1,388.00 |

Under the documented convention — **positive means Prayag is cheaper** — today's gap is:

```
(1388.00 − 1262.35) ÷ 1262.35 = +9.95%
```

Report, for this single row:

1. What the dashboard displays as its gap today.
2. The exact two numbers the code divides, and which table each comes from.
3. Whether the Prayag side is read live from `mrp_price_history` or from the stored `competitor_prices.prayag_mrp_at_compare` snapshot.

Point 3 matters most. The schema comment on `prayag_mrp_at_compare` says the competitor gap is computed **only** against that persisted value and never from a fresh lookup — but the project notes say analysis is live-computed and gaps are never stored. Both cannot be true for the same view. If the dashboard reads a snapshot captured before the rebuild, it is showing the old prices no matter what the history now contains, and reloading will never change it.

Do not adjust any figure to reach an expected number. Report what the code does and where its two inputs come from; the fix follows from that.

---

## 5. Review the 556 inactivated codes

556 codes were marked inactive as absent from the rebuild source. The known legacy population was 406, so roughly 150 are newly inactive and some may be extraction gaps rather than genuine orphans.

From the saved list, report the count grouped by division and the 20 most recently updated. Pay particular attention to CP and Hardware — CP has the most complex sheet structure, and Hardware's 277 codes sit in only two sheets, so a miss there would be systematic rather than scattered.

Do not delete any of them. Inactive is reversible; deleted is not.

---

## 6. Acceptance tests

```
1.  mrp_price_history holds 12,750 rows and 6,303 distinct item codes.
2.  No row exists for any of the 18 listed codes at effective_date = '2026-09-01'.
3.  616-D resolves to 2,490 at asOf = 2026-08-31 and returns nothing at 2026-09-01.
4.  Exactly 98 catalog_products rows have a non-null discontinued_from, matching
    sheet 2_Confirmed_discontinued.
5.  BD-40 resolves to 3,990 today and has no discontinued_from.
6.  All 61 codes in sheet 1 resolve to a price on their division's next revision date.
7.  Products live at asOf = 2026-09-01 total 6,205.
8.  Re-running the loader against the same source does NOT re-mark any of the 61.
9.  The 150 Sparsh mappings still resolve to a catalog_products row.
```

Tests 8 and 3 are the point of the exercise. Correcting 61 rows without correcting the rule leaves the defect in place; and a withdrawn product must keep its earlier price, or comparisons dated before the withdrawal break.

---

## 7. Report back

Read every figure from the database, not from this prompt:

- Row count and distinct codes, before and after. Expected: 12,768 → 12,750, codes unchanged at 6,303.
- Codes with a non-null `discontinued_from`, before and after. Expected: 98.
- Products live at `asOf = 2026-09-01`. Expected: 6,205.
- The single-row trace from §4, with both input numbers and their source tables.
- The 556 inactive codes grouped by division.

---

## 8. One open item, not for you to decide

The nine 600-series codes are withdrawn on 01 Sep 2026, and the price-list owner has confirmed it — the live sheet shows the withdrawal marker with the September price cells cleared. No further action, and no need to seek confirmation again.

Separately: this correction exists only because someone happened to view the live sheet. The database still cannot say which download any price came from. That is addressed in `Replit_MRP_Source_Provenance_Prompt.md`, which should run **after** this one, so the provenance record reflects the corrected 12,750-row state rather than the 12,768-row one.

One clean commit.
