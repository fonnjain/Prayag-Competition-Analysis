# Replit Prompt — Variant Pricing for Sanitaryware

## 1. The gap

`mrp_price_history` is keyed on `(item_code, effective_date)`. It can hold **one** price per code per period. Sanitaryware needs four.

Sanitaryware is the only division that prices colour variants against a **single Cat No.** Every other division gives each variant its own code — sinks use `911-D` and `911-DM`, PTMT uses `148-LS` / `148-LSB` / `148-LSG`, CP uses `6802` and `6802-G`. Sanitaryware puts four prices in four columns against one code:

| Column | Variant |
|---|---|
| F / J | White |
| G / K | Ivory |
| H / L | White with Jet |
| I / M | Pink / Green / Blue |

Only the White price is currently held. The other three are absent from the app entirely.

| | Rows |
|---|---:|
| Sanitaryware price rows in the source, all variants | 838 |
| Already held as the code price (White) | 538 |
| **Missing from the database** | **300** |
| — Ivory | 236 |
| — White with Jet | 38 |
| — Pink / Green / Blue | 26 |

That is **123 of 271 items** carrying at least one colour price the system cannot see — roughly 45% of the sanitaryware range.

Input file: `Prayag_Sanitaryware_Variant_Prices.xlsx`, sheet `rows_to_add` (300 load-ready rows) with `full_variant_matrix` as the four-column view for checking.

---

## 2. Schema

Add to `mrpPriceHistoryTable` in `lib/db/src/schema/catalog.ts`:

```ts
variant: text("variant").notNull().default("Standard"),
```

Then change the unique index from `(item_code, effective_date)` to **`(item_code, effective_date, variant)`**, and run `pnpm --filter @workspace/db run push`.

**`Standard` is the base variant and it carries the existing behaviour.** All 12,750 current rows become `Standard` by default, including the sanitaryware White prices — White *is* the base article, not a colour option, which is why it should not be renamed to "White". A product with no colour options simply has one `Standard` row, exactly as today.

This choice matters: it means every existing query returns the same result as before without being rewritten. Only code that explicitly asks for a variant sees anything new.

---

## 3. Resolution rules

**Price resolution defaults to `variant = 'Standard'`.** Anywhere a current price is resolved — `recomputeCurrentFlags()`, `analysis.ts`, `comparison.ts`, `priceFinder.ts`, `catalogImportExport.ts` — the query must filter to `Standard` unless a variant is explicitly requested.

Get this wrong and every sanitaryware product returns up to four rows where one is expected, quietly multiplying rows in the dashboard, the comparison and every export. **Verify the row counts on those pages before and after; they must be identical.**

`is_current` follows the same rule: it is computed per `(item_code, variant)`, so the current Ivory price is flagged current within Ivory. It does not compete with `Standard`.

Competitor comparison stays on `Standard` only. There is no competitor colour mapping, and comparing a Sparsh price against an Ivory MRP would be meaningless.

---

## 4. Loader

The sanitaryware loader must read all four colour columns rather than the first. The columns are fixed for both periods — F–I for 15 Jan 2026, J–M for 01 May 2026 — but detect them by the sub-header text (`White`, `Ivory`, `White with Jet`, `Pink / Green / Blue`) rather than by position, since position is exactly what has caused every previous defect on this project.

An empty colour cell means that variant is not offered. Write no row for it. Do not fall back to the White price.

---

## 5. Surfacing

On the product detail view, show the colour prices as a small table when a product has more than one variant. Do not show a variant row for products that only have `Standard` — that would put an empty "Standard" label on 6,000 products that have no colour options.

In Price Finder results, where a product has colour variants, show the `Standard` price with a quiet indicator such as *"+3 colour options"*. The list stays one row per product; the variants belong on the detail view.

---

## 6. Acceptance tests

```
1.  mrp_price_history has 13,050 rows (12,750 + 300) and 6,303 distinct item codes.
    The code count must NOT change — these are new variants of existing codes.
2.  Every pre-existing row has variant = 'Standard'.
3.  Resolving a price WITHOUT specifying a variant returns exactly one row per code.
    Test on a sanitaryware item that has all four variants.
4.  4001 (DRENCHE) resolves to 94,400 at asOf = 2026-05-01 with no variant specified.
5.  A sanitaryware item with an Ivory price returns it when variant='Ivory' is
    requested, and returns the Standard price when it is not.
6.  Requesting variant='Ivory' on a product that has no Ivory price returns nothing —
    it does NOT fall back to Standard.
7.  Dashboard, Comparison and Price Finder row counts are IDENTICAL before and after
    this change. Report both numbers.
8.  The 150 Sparsh Pearl comparisons are unchanged, and all resolve against Standard.
9.  Re-running the sanitaryware loader is idempotent — no duplicate variant rows.
```

Test 7 is the one that catches the likely failure. A missing `Standard` filter will not throw an error; it will silently multiply rows, and the page will still render.

---

## 7. Report back

Read every figure from the database, not from this prompt:

- Row count before and after. Expected 12,750 → 13,050.
- Distinct item codes before and after. Expected 6,303 both times.
- Rows per variant.
- Dashboard, Comparison and Price Finder row counts before and after.
- Confirmation that all nine acceptance tests pass.

---

## 8. Related, but not in scope

79 codes carry two prices in the same period from the Pipes & Fittings PE-AL-PE sheets, split as `BRASS MRP` and `BLACK MRP` — the same modelling problem in a different division, currently recorded as Data Health conflict flags. The `variant` column will accommodate them once someone confirms what the two materials should be called and whether both are sold.

Do not migrate those in this task. Build the mechanism here, on the case that is fully understood, and use it for the fittings afterwards.

One clean commit.
