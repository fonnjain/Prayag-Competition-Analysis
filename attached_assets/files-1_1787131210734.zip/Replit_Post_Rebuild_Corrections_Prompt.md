# Replit Prompt — Post-Rebuild Corrections

Three follow-ups to the MRP history rebuild (`99090b4`). The rebuild itself was correct — 12,768 rows, 6,303 codes, the four unsourced periods gone, all 150 Sparsh mappings intact. These are the loose ends.

Input file: `Prayag_Discontinued_Correction.xlsx`

---

## 1. BD-40 was not a one-off — 61 codes are wrongly discontinued

You cleared `BD-40`'s withdrawal date because an acceptance test caught it. It was not a special case. **Sixty more codes have the same defect**, and nothing will catch them: they will simply disappear from the catalogue on their division's revision date.

### Cause

The CP `MASTER` sheet holds **one row per (range, code) pair**. A shared component appears once for every range that uses it. `BD-40` — Single Lever Basin Mixer body — appears in about 89 rows: ASPIRE 52, ORBIT 53, AQUA 54, OCEAN 55, POLO 60, BLAZE 62, VIRGO P66, VINCENT 66, MARCUS 68, MACASA 76, URBONA 78, SAGA 79F, CYGNUS 71, EVIAN 87, NIAGARA 81, EUROPA 90, LAGUNA 93, and others.

When a **range** is withdrawn — EMERALD 61, OPUS 89 — the rows for that range read `REMOVED`. The component itself continues in every other range. `BD-40` has **12 REMOVED rows and 77 clean ones**.

The load treated a single `REMOVED` anywhere as a withdrawal of the code. That is wrong for any sheet keyed by (range, code).

### The correct rule

> A code is discontinued only when **every** row carrying it is marked `REMOVED`. If any row carries a live price for the same period, the code is live.

98 of the 159 meet that test. 61 do not.

### What to do

- **Sheet `1_UNMARK_not_discontinued`** — 61 codes. Set `discontinued_from = NULL` on each. `BD-40` is in this list; clearing it again is a no-op.
- **Sheet `2_Confirmed_discontinued`** — 98 codes. These keep their `discontinued_from`. Verify the database matches this list exactly: no code outside it should carry a withdrawal date.
- **Fix the rule in the loader**, not just the rows. Wherever `REMOVED` is interpreted, group by code first and require every occurrence to be marked before setting a withdrawal date. Otherwise the next load reintroduces all 61.

Sheet `3_MRP_01Sep2026_corrected` is the resulting price list in force on 01 Sep 2026 — **6,205 products**, not 6,144. Use it to check the count after applying.

---

## 2. The competitor gap formula needs a single-row trace, not a re-run

You reported the median Sparsh gap moving from **−8.48% to −0.99%** where the brief predicted **+3% → +10.8%**. Do not chase this with dataset-wide medians. Two facts narrow it down:

- The **shift** is +7.49 points against a predicted +7.8. Near-identical — so the rebuild moved the data correctly.
- The **baseline** differs by a consistent ~11.6 points and the sign is inverted.

Right magnitude, wrong sign and offset, is the signature of a formula problem, not a data problem.

### Trace this one row

Prayag `134-V` (Sink Mixer Foam Flow with Flange) ↔ Sparsh Pearl `RPS-2285`:

| Value | Amount |
|---|---:|
| Prayag MRP w.e.f. 05 Mar 2026 | 1,262.35 |
| Prayag MRP w.e.f. 01 Sep 2026 | 1,364.00 |
| Sparsh Pearl Vol 6.2 MRP | 1,388.00 |

Under the documented convention — **positive means Prayag is cheaper** — today's gap is:

```
(1388.00 − 1262.35) ÷ 1262.35 = +9.95%
```

Report, for this single row:

1. What the dashboard displays as its gap today.
2. The exact two numbers the code divides, and which table each comes from.
3. Whether the Prayag side is read live from `mrp_price_history` or from the stored `competitor_prices.prayag_mrp_at_compare` snapshot.

Point 3 matters. The schema comment on `prayag_mrp_at_compare` says the competitor gap is computed **only** against that persisted value and never from a fresh lookup — but the project notes say analysis is live-computed and gaps are never stored. Both cannot be true for the same view. If the dashboard is reading a snapshot captured before the rebuild, it is showing the old prices regardless of what the history now contains, and no amount of reloading will change it.

Do not adjust any figure to reach an expected number. Report what the code does and where the two inputs come from; the fix follows from that.

---

## 3. Review the 556 inactivated codes

556 codes were marked inactive as absent from the rebuild source. The earlier known legacy population was 406, so roughly 150 are newly inactive and some may be extraction gaps on my side rather than genuine orphans.

From the saved list, report the count grouped by division, and the 20 most recently updated. Pay particular attention to CP and Hardware — CP has the most complex sheet structure, and Hardware's 277 codes sit in only two sheets, so a miss there would be systematic rather than scattered.

Do not delete any of them. Inactive is reversible; deleted is not.

---

## 4. Acceptance tests

```
1. Exactly 98 catalog_products rows have a non-null discontinued_from, and the set
   matches sheet 2_Confirmed_discontinued.
2. BD-40 resolves to 3,990 today and has no discontinued_from.
3. All 61 codes in sheet 1 resolve to a price on their division's next revision date.
4. Products live at asOf = 2026-09-01 total 6,205.
5. Re-running the loader against the same source does NOT re-mark any of the 61 —
   the grouped rule holds, not just the corrected rows.
6. The 150 Sparsh mappings still resolve to a catalog_products row.
```

Test 5 is the point of the exercise. Correcting 61 rows without correcting the rule leaves the defect in place.

---

## 5. Report back

Read from the database, not from this prompt:

- Codes with a non-null `discontinued_from`, before and after. Expected: 98.
- Products live at `asOf = 2026-09-01`. Expected: 6,205.
- The single-row trace from §2, with both input numbers and their source tables.
- The 556 inactive codes grouped by division.

One clean commit.
