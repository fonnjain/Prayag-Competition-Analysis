# Replit Prompt — Price Finder (with voice lookup)

A new tile in the app: pick a product and instantly see Prayag's MRP alongside every competitor's price. Includes a hands-free voice lookup for people checking a price while standing in front of a customer.

> Paste everything below (from **GOAL**) into the Replit AI Agent.

---

## GOAL

Add a **Price Finder** page to the nav (alongside Catalog, Comparison, Mapping Review, Load MRP, Import Competitor). Two ways in — browse by category, or ask by voice. Either way the answer is the same card: **Prayag's MRP, large and bold**, then every competitor's MRP with the gap.

Read-only. It queries existing data and writes nothing.

## Conventions

- Contract-first: edit `lib/api-spec/openapi.yaml`, run `pnpm --filter @workspace/api-spec run codegen`. Never hand-edit `lib/api-hooks` or `lib/api-zod`.
- Drizzle for DB access. Gaps computed live, never stored.
- Prices resolve **by date**: latest `effective_date <= CURRENT_DATE`, for Prayag and competitors alike. Never read `is_current` as the source of truth.
- Competitor price basis: `MRP` → use as-is; `Ex-GST` → `× (1 + gstPct/100)`.

---

## 1. Know the data before designing the UI

Three facts shape this page. Design around them rather than discovering them later:

| Fact | Consequence |
|---|---|
| **6,330 products**, only **150** have any competitor price | ~98% of lookups show Prayag alone. The no-competitor state is the *common* case, not an edge case — it must look deliberate, not broken. |
| **2,494 products have no category** (Hardware has none at all) | A category-only drill-down dead-ends for 39% of the catalogue. Search must be the primary path. |
| Prices are period-aware, and PTMT has a **01 Sep 2026** revision pending | Always show the effective date next to each price, and surface an upcoming price when one exists. |

Upload `Prayag_Category_Backfill.xlsx` and fill the gaps first: it carries `item_code`, `division`, `category`, `product_name` for all 6,330 items, with **5,883 categorised** (93%). Upsert `category` on `catalog_products` where it is currently null or blank. The remaining 447 stay uncategorised — group them under their division rather than hiding them.

## 2. Finding a product — search first, browse second

**Search is the primary control.** A single input at the top, autofocused, matching on **item code, product name, and category** at once. Type-ahead, debounced ~200 ms, capped at ~20 results. Someone who knows they want `121-B` should reach it in one action, not four.

Show for each result: code, name, category, and Prayag's current MRP, so the list itself often answers the question.

**Browse is the fallback**, for when the user doesn't know what it's called: Division → Category → Product. Show counts on each option so dead ends are visible before they're entered. Products with no category appear under an "Uncategorised" group within their division — never dropped.

Add a server endpoint `GET /api/price-finder/search?q=` returning code, name, division, category, current MRP, and a `hasCompetitorData` boolean. Match on prefix and substring, rank exact code matches first.

## 3. The result card

The point of the page. One product, everything known about its price.

**Prayag block** — the hero. MRP set large and bold, with the item code, full product name, division and category above it, and `w.e.f. <effective date>` quietly beneath. Where an upcoming revision exists, add one line: *"From 01 Sep 2026: ₹406"*. Do not let it compete with the current price.

**Competitor block** — one row per competitor: name, their MRP, their effective date, and the gap. Sort by gap so the cheapest competitor is immediately visible. State the gap in words, not just a signed number — *"Prayag is 4.9% cheaper"* reads correctly at a glance; `+4.9%` requires the reader to remember the sign convention. Colour by direction, but never rely on colour alone.

**When there is no competitor data** — which is most of the time — say so plainly and usefully: *"No competitor mapping for this product yet."* Do not render an empty table or a zero. This is a normal state.

`GET /api/price-finder/product/{itemCode}` returns the Prayag block, the upcoming price if any, and the competitor array with each competitor's price, basis, effective date, and computed gap.

## 4. Voice lookup

A microphone button beside the search field. The user says something like *"Quadra bib cock fifteen mm"* or *"one twenty one B"* and gets the same result card.

Use the browser's **Web Speech API** (`webkitSpeechRecognition` in Chrome), with `lang = 'en-IN'` — this materially improves recognition of Indian English and of product vocabulary like "bib cock" and "PTMT". No API cost, no audio leaves the browser in Chrome's implementation.

**Design for mishearing, because it will happen.** Product names are unusual words and codes are alphanumeric; the transcript will often be imperfect.

- **Always show the transcript**, in an editable field. The user corrects a wrong word instead of repeating the whole phrase.
- **Never auto-open a single result.** Return the **top 3 matches** ranked, and let the user tap. A confidently wrong price is far worse than one extra tap.
- **Normalise spoken numbers** before matching: "one twenty one B" → `121-B`, "fifteen mm" → `15mm`, "one and a half inch" → `1½"`. Handle "dash"/"hyphen" as separators.
- **Handle the failure states in the interface's own voice**: microphone permission denied, no speech detected, no match found — each with the next action, not an apology.
- **Feature-detect and degrade.** Firefox has no support and Safari's is partial. Where unsupported, hide the button rather than showing one that fails. Requires HTTPS — Replit provides it.

Match the transcript server-side through the same search endpoint, scoring across code, name, and category. If the top score is weak, return the three best anyway and label them as guesses rather than returning nothing.

## 5. Look and feel

This is a tool used standing up, often on a phone, often mid-conversation with a customer. Design for **glanceability and one-handed use**, not for a dashboard.

- The Prayag MRP is the largest thing on the screen by a clear margin. Everything else is support.
- Tabular figures for all prices so digits align down the competitor list.
- Touch targets comfortably large; the microphone and the search field both reachable with a thumb.
- Keep it consistent with the existing app shell — this is a new tile in a familiar product, not a separate design language.
- Meet the quality floor without drawing attention to it: responsive to mobile, visible keyboard focus, `prefers-reduced-motion` respected, and colour never the only carrier of meaning.

## Validation

- Searching `121-B` returns it first; the card shows Prayag **₹244.08** w.e.f. **2026-04-20**, and Sparsh Pearl **₹273** with *"Prayag is 11.8% cheaper"*.
- `WC-182` shows Prayag **₹144**, Sparsh Pearl **₹151**, gap **+4.9%**.
- `U21` (no competitor mapping) shows **₹78** w.e.f. 2026-02-01 and the plain no-competitor message — no empty table.
- A PTMT item with a pending revision shows the current price as the hero and the 01 Sep 2026 price as a single secondary line.
- Browsing Hardware still lists all 280 products despite having no categories.
- Voice: saying *"one twenty one B"* yields `121-B` among the top 3, with the transcript visible and editable.
- Denying microphone permission produces a clear message and leaves search fully usable.
- The page issues no writes — verify no INSERT/UPDATE reaches any table.
