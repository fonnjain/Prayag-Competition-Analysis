# Replit Prompt — Post-Rebuild Corrections (v4)

Supersedes v3. **v3 has not been run** — the provenance report shows 12,768 linked history rows, which is the pre-correction figure. Run this instead; it carries everything from v3 plus three items arising from the provenance work.

**New in v4:** section 4 (provenance repairs), section 7 (test triage), and the full PTMT digest in section 4.1.

Input file: `Prayag_Discontinued_Correction.xlsx`

---

## 1. The withdrawal-marker rule

Two defects have come from misreading `REMOVED`. Fix the rule once, in the loader, and both go away. Sections 2 and 3 are consequences of getting this right.

**Part one — a price and a withdrawal marker are not in conflict.** They answer different questions. The price column answers *what does it cost*; the status column answers *is it still on the list*. A price cannot contradict a withdrawal marker because it was never making a claim about existence. When a code carries both for the same period, **the marker governs whether the product exists; the price governs what it would cost if it did.** Record both.

**Part two — every row must agree before a code is withdrawn.** A code is withdrawn only if **every** row carrying it in that period is marked withdrawn. The CP `MASTER` sheet holds one row per (range, code) pair, so a shared component appears once per range that uses it. `BD-40` sits in about 89 rows and has **12 removed rows against 77 clean ones**. Group by code first, then require unanimity within the period.

---

## 2. Apply the rule: 61 codes are wrongly discontinued

`BD-40` was not a special case — sixty more carry the same defect, and nothing will catch them. They will disappear from the catalogue on their division's revision date, silently. Under part two, 98 of the 159 are genuinely withdrawn and 61 are not.

- **Sheet `1_UNMARK_not_discontinued`** — 61 codes. Set `discontinued_from = NULL`.
- **Sheet `2_Confirmed_discontinued`** — 98 codes keep their `discontinued_from`. No code outside this list should carry one.
- **Fix the loader**, not just the rows, or the next load reintroduces all 61.

---

## 3. Delete 18 price rows that do not exist in the source

The nine 600-series sinks and their nine Matt twins each hold a `2026-09-01` row carrying a price:

```
616-D  618-D  620-D  622-D  623-D  624-D  624-XD  624-SD  625-D
616-DM 618-DM 620-DM 622-DM 623-DM 624-DM 624-XDM 624-SDM 625-DM
```

In the 19 August download those September cells held computed values — 2,690 / 2,860 / 3,040 and so on. In the **live Google Sheet** the same cells are **empty**; only the `Removed` marker is present. The values were cleared at source.

Delete those 18 rows. Keep every `2026-03-05` row for the same codes — `616-D` must still resolve to 2,490 on 31 August 2026. History goes from **12,768 to 12,750 rows**; distinct codes stay at **6,303**.

They are unreachable today, since a withdrawn product never resolves on or after its withdrawal date. Delete them regardless: they are figures Prayag never published, and if the withdrawal were reversed they would quietly become live prices.

---

## 4. Provenance repairs

The provenance work in `216d29c` is sound. Three corrections follow from it.

### 4.1 The full PTMT digest

You correctly declined to invent a digest from a 16-character prefix. Here are all six in full. Five should match what you computed locally; the sixth completes the PTMT record.

```
5da96e39cac40ede1480be4013554753cbdf4589ff0b5f77a7be43bfe13c8db0    918578   NEW PTMT MRP w.e.f. List as on 01st Sep, 2026.xlsx
03afec64dd7fa66d5108c1099054e74ee86fca39bee0a1f0134c283ec97528c9   2168993   MRP w.e.f. 01st Feb, 2026 Pipe & Fitting.xlsx
82f7f52c5a83ca9f050c65099725bf30dfca8c921cd08d14c2e4b5dfadb7edbf    872767   New CP MRP w.e.f. 01st Aug, 2026.xlsx
ca729a94d1714c663ec0107c1d30e7e39ad56b4944fc72a241cd993a3a833758    202052   SANITARYWARE NEW MRP w.e.f. 01st May, 2026.xlsx
d5a80e00f732af17f21ae7cdda61581354ad537045d939cecbe36338d08cc9e7    114001   NEW HARDWARE Price List as on 01st Mar, 2026.xlsx
b867beecfce9f079d8f75a0785fa3058da81dea38c3bd6ae09256779a4c30796    152291   MRP w.e.f. 15th Feb, 2024 QUAA & FERN.xlsx
```

Report any file whose locally computed digest differs from the value above. A mismatch would mean the copy in the workspace is not the copy the rebuild was built from, which matters more than the hash itself.

### 4.2 `row_count` must be immutable

Section 3 deletes 18 rows from a batch that has already been recorded. That will make `mrp_load_batches.row_count` disagree with the rows currently linked to it.

**Do not update `row_count` to match.** It records what the load wrote — a historical fact that never changes. Add a separately computed figure for rows currently linked, derived live rather than stored.

The divergence is the point. If `row_count` is silently corrected, the audit trail loses the only thing it was built to preserve: evidence that data changed after it was loaded.

### 4.3 Show the divergence, and why

On Data Health, where a batch's loaded count and current linked count differ, show both with a reason. Add a `correction_note` column to `mrp_load_batches` and set it for the PTMT batch:

```
18 September rows removed 19 Aug 2026 — the 600-series September MRP cells
were cleared in the source sheet after this snapshot was taken.
```

Render as, for example: *"PTMT — loaded 4,333 rows on 19 Aug; 4,315 currently linked; 18 removed."* Use the actual figures from the database, not these.

This answers your proposed task **#130**. Manual corrections do not need a parallel audit system — they need this divergence surfaced with a reason recorded against it. Close #130 in favour of this section, or keep it and note that it is covered here.

---

## 5. The competitor gap formula needs a single-row trace

The median Sparsh gap moved from **−8.48% to −0.99%** against a predicted **+3% → +10.8%**. Do not chase this with dataset-wide medians. The **shift** is +7.49 points against a predicted +7.8 — near-identical, so the rebuild moved the data correctly. The **baseline** differs by a consistent ~11.6 points with the sign inverted. Right magnitude, wrong sign and offset, is a formula problem, not a data problem.

### Trace this one row

Prayag `134-V` (Sink Mixer Foam Flow with Flange) ↔ Sparsh Pearl `RPS-2285`:

| Value | Amount |
|---|---:|
| Prayag MRP w.e.f. 05 Mar 2026 | 1,262.35 |
| Prayag MRP w.e.f. 01 Sep 2026 | 1,364.00 |
| Sparsh Pearl Vol 6.2 MRP | 1,388.00 |

Under the documented convention — **positive means Prayag is cheaper** — today's gap is `(1388.00 − 1262.35) ÷ 1262.35 = +9.95%`.

Report, for this single row:

1. What the dashboard displays as its gap today.
2. The exact two numbers the code divides, and which table each comes from.
3. Whether the Prayag side is read live from `mrp_price_history` or from the stored `competitor_prices.prayag_mrp_at_compare` snapshot.

Point 3 matters most. The schema comment on `prayag_mrp_at_compare` says the gap is computed **only** against that persisted value and never from a fresh lookup, while the project notes say analysis is live-computed and gaps are never stored. Both cannot be true for the same view. If the dashboard reads a pre-rebuild snapshot, it shows old prices no matter what the history contains, and reloading will never change it.

Do not adjust any figure to reach an expected number.

---

## 6. Review the 556 inactivated codes

556 codes were inactivated as absent from the rebuild source. The known legacy population was 406, so roughly 150 are newly inactive and some may be extraction gaps rather than genuine orphans.

Report the count grouped by division and the 20 most recently updated. Pay particular attention to CP and Hardware — CP has the most complex sheet structure, and Hardware's 277 codes sit in only two sheets, so a miss there would be systematic rather than scattered.

Do not delete any of them. Inactive is reversible; deleted is not.

---

## 7. Triage the failing tests properly

The last report described the remaining failures as *"previously known unrelated failures in catalogue matching, SINK acceptance data, and PDF extractor expectations."*

**SINK acceptance data is not unrelated.** It covers the exact sheet and the exact codes changed twice this week. A stale expectation and a real regression are indistinguishable in a summary line, and this project has been caught by that before.

For each failing test, report: test name, expected value, actual value, and a judgement of which of two cases it is —

- **Stale expectation** — the test encodes a value we have deliberately corrected. Update the test to the new value and say which correction it reflects.
- **Real regression** — the code now produces something the source does not support. Fix the code.

Do not update any expectation to match actual output without stating which source change justifies it. That is how a regression gets written into a test as if it were intended.

---

## 8. Acceptance tests

```
1.  mrp_price_history holds 12,750 rows and 6,303 distinct item codes.
2.  No row exists for any of the 18 listed codes at effective_date = '2026-09-01'.
3.  616-D resolves to 2,490 at asOf = 2026-08-31 and returns nothing at 2026-09-01.
4.  Exactly 98 catalog_products rows have a non-null discontinued_from, matching
    sheet 2_Confirmed_discontinued.
5.  BD-40 resolves to 3,990 today and has no discontinued_from.
6.  All 61 codes in sheet 1 resolve to a price on their division's next revision date.
7.  Products live at asOf = 2026-09-01 total 6,205.
8.  Re-running the loader against the same source does NOT re-mark any of the 61.
9.  Every mrp_price_history row still has a load_batch_id after the 18 deletions.
10. The PTMT batch's stored row_count is UNCHANGED by the deletions, while its
    live linked count is 18 lower, and Data Health shows both.
11. The 150 Sparsh mappings still resolve to a catalog_products row.
```

Tests 8 and 10 are the point of the exercise. Correcting 61 rows without correcting the rule leaves the defect in place; and silently reconciling `row_count` destroys the audit trail the provenance work just created.

---

## 9. Report back

Read every figure from the database, not from this prompt:

- Row count and distinct codes, before and after. Expected: 12,768 → 12,750, codes unchanged at 6,303.
- Codes with a non-null `discontinued_from`, before and after. Expected: 98.
- Products live at `asOf = 2026-09-01`. Expected: 6,205.
- Per batch: stored `row_count`, live linked count, and the difference.
- Any source file whose local digest differs from section 4.1.
- The single-row trace from section 5, with both input numbers and their source tables.
- The 556 inactive codes grouped by division.
- The test triage from section 7, one line per failing test.

One clean commit.
