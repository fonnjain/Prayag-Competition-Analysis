# Replit Prompt — Post-Rebuild Corrections (v6)

Supersedes v5, which was never run. Rebased on `99cfb12`, which landed variant pricing and completed one of v5's items.

**Already done — do not redo:**
- The 18 phantom September rows for the 600-series sinks are deleted. Baseline is now **13,048 rows = 12,750 Standard + 298 colour**.
- `mrp_price_history.variant` exists with the three-column unique index.
- `deriveConfirmedDiscontinuations()` implements parts one and two of the rule below.

**Still outstanding, and the reason for this prompt:** part three of the rule, and the 69 records it affects.

Input file: `Prayag_Discontinued_Correction_v2.xlsx`

---

## 1. The withdrawal-marker rule — part three is missing

The loader decides who gets a `discontinued_from` by looking for `REMOVED` in the source workbooks. Two tests are in place. A third is not, and its absence is hiding live products.

**Part one — a price and a marker are not in conflict.** They answer different questions and both get recorded. *Implemented.*

**Part two — every row carrying a code must say `REMOVED` before it counts.** The CP `MASTER` sheet is keyed by (range, code), so a shared component like `BD-40` appears in ~89 rows; when a range is withdrawn its rows read `REMOVED` while the component continues elsewhere. *Implemented as `allRemoved`.*

**Part three — a marker only withdraws the period whose column it occupies.** *Not implemented.*

A `REMOVED` in an older period's column means the product was withdrawn **at that older date**. If a later period then carries a real price, the product was **reintroduced**. The current code scans a row, finds the word `REMOVED` anywhere, and stamps the workbook's newest date on the product.

### What this is doing right now

Eight water tanks carry `REMOVED` against the **01 May 2024** column and a live price against **01 Feb 2026**:

| Code | Capacity | MRP w.e.f. 01 Feb 2026 |
|---|---|---:|
| `WT-3LH-05` | 500 L | 10,000 |
| `WT-3LH-07` | 750 L | 15,000 |
| `WT-3LH-10` | 1,000 L | 20,000 |
| `WT-3LH-15` | 1,500 L | 30,000 |
| `WT-3LH-20` | 2,000 L | 40,000 |
| `WT-3LH-30` | 3,000 L | 60,000 |
| `WT-3LH-50` | 5,000 L | **1,00,000** |
| `WT-4LH-05` | 500 L | 12,500 |

All eight were stamped `discontinued_from = 2026-02-01`. That date is already past, so they are **invisible in the catalogue and Price Finder today** — including a tank priced at one lakh.

The SINK handler avoids this by reading a specific column. The generic path never checks.

### The change

`SourceRemovalRow` in `lib/discontinuationPolicy.ts` is `{ itemCode, discontinuedFrom, isRemoved }`. It has no field that could carry which column a marker came from, so the shape must change. Something like:

```ts
export interface SourceRemovalRow {
  itemCode: string;
  markerPeriod: string | null;        // effective_date of the column holding the marker
  latestPricedPeriod: string | null;  // latest period with a real price for this code
  isRemoved: boolean;
}
```

A code is withdrawn only when **every** occurrence is marked (part two) **and** no priced period falls on or after the earliest marker period (part three). If a later price exists, the product was reintroduced and must stay live.

Check both cases hold:
- `616-D` — marker at 2026-09-01, no price on or after → **withdrawn**, as now.
- `WT-3LH-50` — marker at 2024-05-01, priced at 2026-02-01 → **live**.

---

## 2. Apply it: 69 codes are wrongly discontinued

Under parts two and three, **90** of the 159 are genuinely withdrawn and **69** are not.

- **Sheet `1_UNMARK_not_discontinued`** — 69 codes, each with its reason. Set `discontinued_from = NULL`. `BD-40` is in this list and was already cleared, so that one is a no-op.
- **Sheet `2_Confirmed_discontinued`** — 90 codes keep their date. No code outside this list may carry one.

**Fixing the 69 rows without fixing the rule is not enough.** The database would be correct until the next MRP load, at which point the loader reads the same workbooks, applies the same incomplete rule, and re-hides all eight tanks — silently, with no error. Section 1 is the durable fix; this section is the cleanup.

`discontinued_from` lives on `catalog_products`, so none of this changes `mrp_price_history`. Row count stays at **13,048**.

---

## 3. Two colour prices are unaccounted for

`variant-pricing.md` records **298** colour rows loaded. The source holds **300**:

| Variant | Source |
|---|---:|
| Ivory | 236 |
| White with Jet | 38 |
| Pink / Green / Blue | 26 |
| **Total** | **300** |

Report which two did not load and why — most likely a duplicate `(item_code, effective_date, variant)` hitting `DO NOTHING`, or a source cell that failed the numeric test. Do not add rows to reach 300; identify the two and explain them. If they are genuine duplicates in the source, say so and leave the count at 298.

---

## 4. Review the 556 inactivated codes

556 codes were inactivated as absent from the rebuild source. The known legacy population was 406, so roughly 150 are newly inactive and some may be extraction gaps rather than genuine orphans.

Report the count grouped by division and the 20 most recently updated. Pay particular attention to CP and Hardware — CP has the most complex sheet structure, and Hardware's 277 codes sit in only two sheets, so a miss there would be systematic rather than scattered.

Do not delete any of them. Inactive is reversible; deleted is not.

---

## 5. Triage the failing tests

`dashboard.chip.test.tsx` — seven tests throw `No QueryClient set` before reaching an assertion. That is a **test-harness gap, not a product regression**: the component calls React Query directly while this test file renders it bare. Confirm the dashboard renders correctly in the running app, then wrap the test file in a `QueryClientProvider`.

For any other failure, report file, test name, expected, actual, and whether it is a stale expectation or a real regression. **Do not update an expectation without naming the source change that justifies it.**

---

## 6. Acceptance tests

```
1.  mrp_price_history holds 13,048 rows: 12,750 with variant='Standard' and 298 others.
2.  Exactly 90 catalog_products rows have a non-null discontinued_from, matching
    sheet 2_Confirmed_discontinued.
3.  WT-3LH-50 resolves to 1,00,000 today and has discontinued_from = NULL.
4.  All 8 water tanks appear in a catalogue query as of today.
5.  BD-40 resolves to 3,990 today and has no discontinued_from.
6.  616-D resolves to 2,490 at asOf = 2026-08-31 and nothing at 2026-09-01 —
    part three must NOT break the genuine withdrawals.
7.  Products live at asOf = 2026-09-01 total 6,213.
8.  Unit test on deriveConfirmedDiscontinuations: a code whose marker sits in an
    EARLIER period than its latest price is NOT returned.
9.  Re-running all six loaders against the same source does not re-mark any of
    the 69, and leaves the row count at 13,048.
10. The 150 Sparsh Pearl comparisons still resolve to a catalog_products row.
```

Tests 6 and 9 are the point. Test 6 guards against over-correcting — the 600-series sinks must stay withdrawn. Test 9 is the only one that proves the rule was fixed rather than the rows patched.

---

## 7. Report back

Read every figure from the database, not from this prompt:

- Row count split by variant. Expected 12,750 Standard + 298 other.
- Codes with a non-null `discontinued_from`, before and after. Expected **90**.
- The 8 water tanks with resolved price and `discontinued_from`.
- Products live at `asOf = 2026-09-01`. Expected **6,213**.
- Which two colour prices are missing, and why.
- The 556 inactive codes grouped by division.
- The test triage.

One clean commit.

---

## 8. A separate question, not part of this task

`99cfb12` was a single commit titled "Sync current Replit workspace" spanning schema changes, five routes, two new frontends and an admin system. The variant work is verifiable because `variant-pricing.md` records acceptance baselines.

The **public Price Finder** and the **admin users / roles** system have no stated baseline. A public-facing price surface and a permissions system are the two places where an untested assumption becomes a live exposure. Before either goes near production, state plainly what verification each received — which routes are unauthenticated, what a signed-out visitor can retrieve, and how roles are enforced server-side rather than only in the UI.

Answer that in the report; do not start work on it here.
